export interface User {
    id: string,
    name: string,
    address: string,
    imgPath: string
}